⁘ WELCOME TO THE MOUTHIVERSE ⁘

The "𓆦 Mouthiverse.jsxbin" file is a dockable panel for After Effects.
To install it, copy the file into the After Effects ScriptUI Panels folder, then restart After Effects.

ScriptUI Panels Directory: 
MacOS: /Applications/After Effects #version#/Scripts/ScriptUI Panels/
Windows: /Program Files/Adobe/Adobe After Effects #version#/Support Files/Scripts/ScriptUI Panels/

Thanks for downloading.

May the little finches chirp as you pass by,
Tommaso

--

Mouthiverse Version 1.11 - 16/02/2025

Stay voracious, 𓆦Vorace